var proyectosDelServidor = [
    { titulo: "Landing de cafeteria",    texto: "Pagina de una pagina con menu y contacto.",  etiqueta: "HTML y CSS",  color: "6b8e9f" },
    { titulo: "Galeria de fotos",        texto: "Grilla de imagenes que se adapta al ancho.", etiqueta: "Bootstrap 3", color: "8f7a66" },
    { titulo: "Calculadora de notas",    texto: "Promedio ponderado con JavaScript basico.",  etiqueta: "JavaScript",  color: "6e8b74" },
    { titulo: "Blog personal",           texto: "Listado de articulos con barra lateral.",    etiqueta: "HTML y CSS",  color: "9a7b8c" },
    { titulo: "Formulario de reservas",  texto: "Validacion de campos y mensajes de ayuda.",  etiqueta: "JavaScript",  color: "7d8ca3" },
    { titulo: "Tarjeta de presentacion", texto: "Ejercicio de tipografia y espaciado.",       etiqueta: "CSS",         color: "a3846b" },
    { titulo: "Menu de restaurante",     texto: "Secciones con precios y fotos.",             etiqueta: "Bootstrap 3", color: "7a8f6b" },
    { titulo: "Contador de clicks",      texto: "Primer ejercicio de eventos en JavaScript.", etiqueta: "JavaScript",  color: "8c7a9a" }
];

var proyectosDeRespaldo = [
    { titulo: "Landing de cafeteria", texto: "Pagina de una pagina con menu y contacto.",  etiqueta: "HTML y CSS",  color: "6b8e9f" },
    { titulo: "Galeria de fotos",     texto: "Grilla de imagenes que se adapta al ancho.", etiqueta: "Bootstrap 3", color: "8f7a66" },
    { titulo: "Calculadora de notas", texto: "Promedio ponderado con JavaScript basico.",  etiqueta: "JavaScript",  color: "6e8b74" },
    { titulo: "Blog personal",        texto: "Listado de articulos con barra lateral.",    etiqueta: "HTML y CSS",  color: "9a7b8c" }
];

var ESPERA_MAXIMA = 5000;
var modoActual = "normal";
var temporizadorRespuesta = null;
var temporizadorDemora = null;

function elemento(id) {
    return document.getElementById(id);
}

function mostrar(id) {
    elemento(id).hidden = false;
}

function ocultar(id) {
    elemento(id).hidden = true;
}

function imagenDeEjemplo(titulo, color) {
    var svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 220'>" +
              "<rect width='400' height='220' fill='#" + color + "'/>" +
              "<text x='200' y='118' font-family='Arial' font-size='22' fill='#ffffff' text-anchor='middle'>" +
              titulo + "</text></svg>";
    return "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg);
}

function dibujarProyectos(proyectos, esCopiaGuardada) {
    var contenedor = elemento("lista-proyectos");
    var html = "";

    if (esCopiaGuardada) {
        html += '<div class="col-xs-12">' +
                '<span class="label label-warning aviso-copia">Informacion guardada, puede no estar actualizada</span>' +
                '</div>';
    }

    for (var i = 0; i < proyectos.length; i++) {
        var p = proyectos[i];

        html += '<article class="col-xs-12 col-sm-6 col-lg-3">' +
                '  <div class="thumbnail tarjeta-proyecto">' +
                '    <img src="' + imagenDeEjemplo(p.titulo, p.color) + '" alt="Vista previa del proyecto ' + p.titulo + '">' +
                '    <div class="caption">' +
                '      <h3>' + p.titulo + '</h3>' +
                '      <p>' + p.texto + '</p>' +
                '      <p><span class="label label-default">' + p.etiqueta + '</span></p>' +
                '      <a href="#proyectos" class="btn btn-primary btn-sm">Ver detalle</a>' +
                '    </div>' +
                '  </div>' +
                '</article>';

        if ((i + 1) % 2 === 0) {
            html += '<div class="clearfix visible-sm-block visible-md-block"></div>';
        }
        if ((i + 1) % 4 === 0) {
            html += '<div class="clearfix visible-lg-block"></div>';
        }
    }

    contenedor.innerHTML = html;
    mostrar("lista-proyectos");
}

function limpiarPantalla() {
    ocultar("estado-carga");
    ocultar("estado-error");
    ocultar("estado-vacio");
    ocultar("aviso-demora");
    ocultar("lista-proyectos");
    elemento("lista-proyectos").innerHTML = "";
}

function marcarCargando(estaCargando) {
    elemento("zona-proyectos").setAttribute("aria-busy", estaCargando ? "true" : "false");
}

function pedirProyectos(modo) {
    clearTimeout(temporizadorRespuesta);
    clearTimeout(temporizadorDemora);

    limpiarPantalla();
    mostrar("estado-carga");
    marcarCargando(true);

    temporizadorDemora = setTimeout(function () {
        marcarCargando(false);
        ocultar("estado-carga");
        mostrar("aviso-demora");
        dibujarProyectos(proyectosDeRespaldo, true);
    }, ESPERA_MAXIMA);

    var demora = 800;
    if (modo === "lenta") {
        demora = 10000;
    }
    if (modo === "error") {
        demora = 1500;
    }

    temporizadorRespuesta = setTimeout(function () {
        clearTimeout(temporizadorDemora);
        marcarCargando(false);

        if (modo === "error") {
            limpiarPantalla();
            mostrar("estado-error");
            dibujarProyectos(proyectosDeRespaldo, true);
            return;
        }

        if (modo === "vacia") {
            limpiarPantalla();
            mostrar("estado-vacio");
            return;
        }

        limpiarPantalla();
        dibujarProyectos(proyectosDelServidor, false);

    }, demora);
}

function mostrarMensajeFormulario(tipo, texto) {
    var caja = elemento("mensaje-formulario");
    caja.className = "alert alert-" + tipo;
    caja.innerHTML = texto;
    caja.hidden = false;
}

function enviarFormulario(evento) {
    evento.preventDefault();

    var nombre = elemento("campo-nombre").value;
    var correo = elemento("campo-correo").value;
    var mensaje = elemento("campo-mensaje").value;

    if (nombre === "" || correo === "" || mensaje === "") {
        mostrarMensajeFormulario("warning", "<strong>Faltan datos.</strong> Completa nombre, correo y mensaje.");
        return;
    }

    var boton = elemento("boton-enviar");
    boton.disabled = true;
    boton.innerHTML = "Enviando...";
    mostrarMensajeFormulario("info", "Enviando tu mensaje...");

    setTimeout(function () {
        boton.disabled = false;
        boton.innerHTML = "Enviar mensaje";

        if (modoActual === "error" || modoActual === "lenta") {
            mostrarMensajeFormulario("danger",
                "<strong>No pudimos enviar tu mensaje.</strong> " +
                "Tus datos siguen escritos en el formulario, puedes presionar " +
                "<em>Enviar mensaje</em> otra vez o escribirnos a " +
                "<a href='mailto:tomas@ejemplo.cl'>tomas@ejemplo.cl</a>.");
            return;
        }

        mostrarMensajeFormulario("success", "<strong>Mensaje enviado.</strong> Te responderemos pronto.");
        elemento("formulario-contacto").reset();
    }, 1500);
}

function cambiarModo(modo) {
    modoActual = modo;
    pedirProyectos(modo);
}

var botonesModo = document.querySelectorAll("[data-modo]");
for (var i = 0; i < botonesModo.length; i++) {
    botonesModo[i].onclick = function () {
        cambiarModo(this.getAttribute("data-modo"));
    };
}

elemento("boton-reintentar").onclick = function () {
    pedirProyectos("normal");
};

elemento("formulario-contacto").onsubmit = enviarFormulario;

pedirProyectos("normal");
